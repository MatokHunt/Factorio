-- Evolution Factor Changes made for very long game play.

-- Time Factor: Turned off. Didn't make sense that enemies evolved from doing nothing.
data.raw["map-settings"]["map-settings"]["enemy_evolution"].time_factor = 0.0
-- Pollution Factor: reduced by 1/3rd. Enemies will still evolve faster the more you pollute their world, but at a slightly lower rate than vanilla.
data.raw["map-settings"]["map-settings"]["enemy_evolution"].pollution_factor = 0.00001
-- Kill Factor: Turned off. Didn't make sense that enemies evolved from getting destroyed.
data.raw["map-settings"]["map-settings"]["enemy_evolution"].destroy_factor = 0.0

-- Tweak what can be crafted by hand.
--[[local ingredients = 0
for i, obj in pairs(data.raw["recipe"]) do
  if obj.category == "" or obj.category == nil then
    obj.category = "crafting"
  end
  if #obj.ingredients > ingredients then ingredients = #obj.ingredients end 
  -- Would have to add quite a few exceptions here to allow game progression, adding them to the hand-crafted category
  if obj.name == "lab" then obj.category = "hand-crafted" end 
end
data.raw["assembling-machine"]["assembling-machine-1"].crafting_categories = data.raw.player.player.crafting_categories

for i, obj in pairs(data.raw["assembling-machine"]) do
  if i:find("assembling%-machine") then
    table.insert(obj.crafting_categories, "hand-crafted")
	obj.ingredient_count = ingredients
  end
end 

data.raw.player.player.crafting_categories = {"hand-crafted"}
--]]
