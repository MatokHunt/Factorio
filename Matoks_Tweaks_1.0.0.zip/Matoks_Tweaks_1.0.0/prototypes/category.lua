data:extend(
{
  {
    type = "recipe-category",
    name = "hand-crafted"
  }
})