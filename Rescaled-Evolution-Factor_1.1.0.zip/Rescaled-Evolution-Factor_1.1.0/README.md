Rescaled Evolution Factor v.1.0.0

German/Deutsch: (English below)

Dieser Mod ändert die Skalierung des Evolutionsfaktors im Spiel, der für die Stärke der Gegner verantwortlich ist.
Im Vanillaspiel steigt dieser mit der Zeit, zerstörten Gegnerspawnern und ausgestoßener Umweltverschmutzung an.
Diese Modifikation setzt dies in ein Verhältnis von 10/20/70 und betrachtet nicht mehr die bisher insgesamt
ausgestoßene Menge an Umweltverschmutzung, sondern nur noch den aktuellen Grad der Verschmutzung (hinsichtlich
Gesamtmenge und relativer Menge im Verhältnis zum Logarithmus der Kartengröße). Dadurch hängt die Gegnerstärke
mehr von den Entscheidungen des Spielers ab. Führte bisher unweigerlich die Zeit zum Erstarken der Gegnerhorden,
so ist dies nun auf 10% begrenzt. Das Bekämpfen von Gegnern hat nun einen direkteren Einfluss, ist aber auf einen
Maximalanteil von 20% begrenzt (Völkermord ist Völkermord...).
70% werden vom aktuellen Grad der Umweltverschmutzung bestimmt. Hier hat der Spieler (also du) nun erstmals die
Möglichkeit zur Reduktion der Gegnerstärke. Reduziert er die Umweltverschmutzung und setzt auf schonende
Energiequellen und sparsame Produktionsmechanismen, so sinkt im Gegenzug die Gegnerstärke.
Setzt ein Spieler, auch im Nachhinein noch, auf Vermeidung von Umweltverschmutzung und Scharmützeln, Bebauung mit
niedriger Dichte und Energiesparsamkeit, so kann er langfristig den Evolutionsfaktor unter 50%, wenn nicht gar auf
10% bis 30% halten. Dies ermöglicht mehr Spieldynamik.

English:

This mod rescales the evolution factor and makes it more dynamic and interactiv. Your dicisions will be influence
the strongness of your enemies!