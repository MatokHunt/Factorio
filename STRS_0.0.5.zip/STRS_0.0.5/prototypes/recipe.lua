data:extend({
  {
    type = "recipe",
    name = "lr-radar",
	enabled = false,
    ingredients =
    {
	  {"advanced-circuit", 10},
      {"electronic-circuit", 15},
	  {"copper-cable", 10},
      {"steel-plate", 10},
	  {"radar", 1}
    },
    result = "lr-radar",
   },
   {
    type = "recipe",
    name = "doppler-radar",
	enabled = false,
    ingredients =
    {
	  {"electronic-circuit", 10},
	  {"copper-cable", 4},
      {"radar", 1}
    },
    result = "doppler-radar",
   },
   
 })